﻿
Partial Class TOPLog_Report_LACount
    Inherits System.Web.UI.Page

End Class
