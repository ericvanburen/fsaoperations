﻿
Partial Class PCAReviews_QCTierReport
    Inherits System.Web.UI.Page

    Public Overrides Sub VerifyRenderingInServerForm(control As Control)
        ' Verifies that the control is rendered 
    End Sub

    Sub btnSearch_Click(ByVal sender As Object, ByVal e As EventArgs)
        dsQCTiersReport.SelectParameters("BeginDate").DefaultValue = txtBeginDate.Text
        dsQCTiersReport.SelectParameters("EndDate").DefaultValue = txtEndDate.Text

        btnExportExcel.Visible = True
    End Sub

    Sub btnSearchAgain_Click(ByVal sender As Object, e As EventArgs)
        Response.Redirect("QCTierReport.aspx")
        btnExportExcel.Visible = False
    End Sub

    Sub btnExportExcel_Click(sender As Object, e As EventArgs)
        ExportExcel()
    End Sub

    Protected Sub ExportExcel()
        GridView1.AllowSorting = False
        Response.Clear()
        Response.AddHeader("content-disposition", "attachment;filename=QCTier_Report.xls")
        Response.Charset = ""
        Response.ContentType = "application/vnd.xls"
        Dim stringWrite As System.IO.StringWriter = New System.IO.StringWriter()
        Dim htmlWrite As System.Web.UI.HtmlTextWriter = New HtmlTextWriter(stringWrite)
        GridView1.RenderControl(htmlWrite)
        Response.Write(stringWrite.ToString())
        Response.End()
    End Sub

End Class
