﻿Imports System.Data
Imports System.Data.SqlClient
Imports Csv

Partial Class CCM_New_FormB
    Inherits System.Web.UI.Page

    Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs)
        If Not Page.IsPostBack Then

            lblUserID.Text = HttpContext.Current.User.Identity.Name

           
        End If

    End Sub

    Protected Sub GridView1_PreRender(ByVal sender As Object, ByVal e As EventArgs)
        If GridView1.Rows.Count > 0 Then
            GridView1.UseAccessibleHeader = True
            GridView1.HeaderRow.TableSection = TableRowSection.TableHeader
        End If
    End Sub
   

    Sub btnSearch_Click(ByVal sender As Object, ByVal e As EventArgs)
        BindGridView()
    End Sub

    Sub btnSearchAgain_Click(ByVal sender As Object, ByVal e As EventArgs)
        Response.Redirect("ChecksSearch.aspx")
    End Sub

    Sub BindGridView()
        Dim strSQLConn As SqlConnection
        Dim cmd As SqlCommand
        Dim ds As DataSet

        strSQLConn = New SqlConnection(ConfigurationManager.ConnectionStrings("CCM2ConnectionString").ConnectionString)
        cmd = New SqlCommand("p_ChecksSearch", strSQLConn)
        cmd.CommandType = CommandType.StoredProcedure

        'p_Search uses dynamic SQL so we pass a value to it only when there is one
        If txtCheckID.Text <> "" Then
            cmd.Parameters.Add("@CheckID", SqlDbType.Int).Value = Convert.ToInt32(txtCheckID.Text)
        End If

        'This one passes a comma-delimited string for @CallCenterID which is used in the split function
        If ddlCallCenterID.SelectedValue <> "" Then
            Dim strSearchValue As String = ""
            Dim li As ListItem
            For Each li In ddlCallCenterID.Items
                If li.Selected = True Then
                    strSearchValue = strSearchValue & li.Value & ","
                End If
            Next
            strSearchValue = Left(strSearchValue, (Len(strSearchValue) - 1))
            strSearchValue = Replace(strSearchValue, ",", ",")
            cmd.Parameters.AddWithValue("@CallCenterID", SqlDbType.VarChar).Value = strSearchValue
        End If

        'This one passes a comma-delimited string for @UserID which is used in the split function
        If ddlUserID.SelectedValue <> "" Then
            Dim strSearchValue As String = ""
            Dim li As ListItem
            For Each li In ddlUserID.Items
                If li.Selected = True Then
                    strSearchValue = strSearchValue & li.Value & ","
                End If
            Next
            strSearchValue = Left(strSearchValue, (Len(strSearchValue) - 1))
            strSearchValue = Replace(strSearchValue, ",", ",")
            cmd.Parameters.AddWithValue("@UserID", SqlDbType.VarChar).Value = strSearchValue
        End If

        If txtDateSubmittedBegin.Text <> "" Then
            cmd.Parameters.Add("@DateSubmittedBegin", SqlDbType.VarChar).Value = txtDateSubmittedBegin.Text
        End If

        If txtDateSubmittedEnd.Text <> "" Then
            cmd.Parameters.Add("@DateSubmittedEnd", SqlDbType.VarChar).Value = txtDateSubmittedEnd.Text
        End If

        If ddlCheckType.SelectedValue <> "" Then
            cmd.Parameters.Add("@CheckType", SqlDbType.VarChar).Value = ddlCheckType.SelectedValue
        End If

        If ddlEscalated.SelectedValue <> "" Then
            cmd.Parameters.Add("@Escalated", SqlDbType.VarChar).Value = ddlEscalated.SelectedValue
        End If

        'Users can search only their own records
        'cmd.Parameters.AddWithValue("@UserID", SqlDbType.VarChar).Value = lblUserID.Text


        Try
            strSQLConn.Open()
            Dim MyAdapter As New SqlDataAdapter(cmd)

            ds = New DataSet()
            MyAdapter.Fill(ds, "Checks")

            Dim intRecordCount As Integer = ds.Tables(0).Rows.Count()
            lblRowCount.Text = "Your search returned " & intRecordCount & " records"

            'ds.Tables(0).DefaultView.Sort = lblSortExpression.Text

            GridView1.DataSource = ds.Tables("Checks").DefaultView
            GridView1.DataBind()

            'Make search again button visible
            'btnSearchAgain.Visible = True
        Finally
            strSQLConn.Close()
        End Try
    End Sub

    Protected Sub btnExportExcel_Click(sender As Object, e As System.Web.UI.ImageClickEventArgs)
        Dim MyConnection As SqlConnection
        MyConnection = New SqlConnection(ConfigurationManager.ConnectionStrings("CCM2ConnectionString").ConnectionString)
        Dim cmd As New SqlCommand("p_ChecksSearch", MyConnection)

        With cmd
            .CommandType = CommandType.StoredProcedure

            'p_Search uses dynamic SQL so we pass a value to it only when there is one
            If txtCheckID.Text <> "" Then
                cmd.Parameters.Add("@CheckID", SqlDbType.Int).Value = Convert.ToInt32(txtCheckID.Text)
            End If

            'This one passes a comma-delimited string for @CallCenterID which is used in the split function
            If ddlCallCenterID.SelectedValue <> "" Then
                Dim strSearchValue As String = ""
                Dim li As ListItem
                For Each li In ddlCallCenterID.Items
                    If li.Selected = True Then
                        strSearchValue = strSearchValue & li.Value & ","
                    End If
                Next
                strSearchValue = Left(strSearchValue, (Len(strSearchValue) - 1))
                strSearchValue = Replace(strSearchValue, ",", ",")
                cmd.Parameters.AddWithValue("@CallCenterID", SqlDbType.VarChar).Value = strSearchValue
            End If

            'This one passes a comma-delimited string for @UserID which is used in the split function
            If ddlUserID.SelectedValue <> "" Then
                Dim strSearchValue As String = ""
                Dim li As ListItem
                For Each li In ddlUserID.Items
                    If li.Selected = True Then
                        strSearchValue = strSearchValue & li.Value & ","
                    End If
                Next
                strSearchValue = Left(strSearchValue, (Len(strSearchValue) - 1))
                strSearchValue = Replace(strSearchValue, ",", ",")
                cmd.Parameters.AddWithValue("@UserID", SqlDbType.VarChar).Value = strSearchValue
            End If

            If txtDateSubmittedBegin.Text <> "" Then
                cmd.Parameters.Add("@DateSubmittedBegin", SqlDbType.VarChar).Value = txtDateSubmittedBegin.Text
            End If

            If txtDateSubmittedEnd.Text <> "" Then
                cmd.Parameters.Add("@DateSubmittedEnd", SqlDbType.VarChar).Value = txtDateSubmittedEnd.Text
            End If

            If ddlCheckType.SelectedValue <> "" Then
                cmd.Parameters.Add("@CheckType", SqlDbType.VarChar).Value = ddlCheckType.SelectedValue
            End If

            If ddlEscalated.SelectedValue <> "" Then
                cmd.Parameters.Add("@Escalated", SqlDbType.VarChar).Value = ddlEscalated.SelectedValue
            End If

            'Users can search only their own records
            'cmd.Parameters.AddWithValue("@UserID", SqlDbType.VarChar).Value = lblUserID.Text

        End With

        Dim da As New SqlDataAdapter(cmd)
        Dim myDataTable As DataTable = New DataTable()
        da.Fill(myDataTable)

        Try
            MyConnection.Open()
            Response.Clear()
            Response.ClearHeaders()
            Dim writer As New CsvWriter(Response.OutputStream, ","c, Encoding.Default)
            writer.WriteAll(myDataTable, True)
            writer.Close()

            Dim FileDate As String = Replace(FormatDateTime(Now(), DateFormat.ShortDate), "/", "")
            Response.AddHeader("Content-Disposition", "attachment;filename=Call_Monitoring_Servicer_Check" & FileDate & ".csv")
            Response.ContentType = "application/vnd.ms-excel"
            Response.End()
        Finally
            If MyConnection.State <> ConnectionState.Closed Then MyConnection.Close()
            MyConnection.Dispose()
            MyConnection = Nothing
            myDataTable.Dispose()
            myDataTable = Nothing
        End Try
    End Sub
   

End Class
