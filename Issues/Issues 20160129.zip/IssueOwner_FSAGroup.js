﻿$(function () {
    var UserID = document.getElementById('MainContent_ddlUserID');
    var FSAGroup = document.getElementById('MainContent_ddlFSAGroup');

    $('select[id$=UserID]').change(function () {
        //if (this.value == 'eric.vanburen' || this.value == 'carolyn.toomer') {
        if (this.value == 'brenda.wallace' || this.value == 'debbe.johnson' || this.value == 'demetrias.fogle'
            || this.value == 'destre.holloway' || this.value == 'helena.myers-wright' || this.value == 'janet.dragoo' || this.value == 'jason.vann'
            || this.value == 'karen.william' || this.value == 'katherine.coates' || this.value == 'larry.porter' || this.value == 'lauren.honemann'
            || this.value == 'lisa.oldre' || this.value == 'mark.walsh' || this.value == 'michael.wood' || this.value == 'sally.young'
            || this.value == 'sherika.roberts' || this.value == 'taisha.winters-ragland' || this.value == 'eric.vanburen') {
            FSAGroup.value = 'Bus Ops';
        } else if (this.value == 'douglas.laine' || this.value == 'bora.kim' || this.value == 'bryan.carmody' || this.value == 'fran.colantonio'
            || this.value == 'katharine.leavitt' || this.value == 'katrina.mcdonald' || this.value == 'kim.meadows' || this.value == 'melissa.butts'
            || this.value == 'nikcola.yorkshire' || this.value == 'shayla.mitchell' || this.value == 'stephanie.lowery' || this.value == 'tracey.stewart') {
            FSAGroup.value = 'FMB Group';
        } else {
            FSAGroup.value = '';
        }
    });
});